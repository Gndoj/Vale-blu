# ValëBlu, Ksamil — MERN Hotel Booking

A beginner-friendly full-stack hotel reservation app built with MongoDB, Express, React (Vite), Node.js, and Bootstrap 5.

## Folder structure

- `backend/` — Express API + Mongoose models
- `frontend/` — React app (Vite)

## Prerequisites

- Node.js 18+
- A MongoDB connection string (local Mongo or MongoDB Atlas)

## Setup

### 1. Backend
```bash
cd backend
cp .env.example .env      # then edit MONGO_URI
npm install
node seed.js              # optional: insert demo rooms + reviews
node server.js
```
Backend runs on http://localhost:5000

### 2. Frontend
```bash
cd frontend
cp .env.example .env      # optional override
npm install
npm run dev
```
Frontend runs on http://localhost:5173

## API Routes

- `GET/POST /rooms`
- `GET/POST /bookings`, `DELETE /bookings/:id`
- `GET/POST /reviews`
- `POST /contact`
