export default function ReviewCard({ review }) {
  return (
    <div className="card h-100 shadow-sm p-3">
      <h6 className="mb-1">{review.userName}</h6>
      <div className="star mb-2">{'★'.repeat(review.rating)}{'☆'.repeat(5 - review.rating)}</div>
      <p className="mb-0">{review.comment}</p>
    </div>
  );
}
