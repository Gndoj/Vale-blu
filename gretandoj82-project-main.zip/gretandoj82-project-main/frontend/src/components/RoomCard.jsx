import { Link } from 'react-router-dom';

export default function RoomCard({ room }) {
  return (
    <div className="card h-100 shadow-sm">
      <img src={room.image} className="card-img-top" alt={room.name} style={{ height: 220, objectFit: 'cover' }} />
      <div className="card-body">
        <h5 className="card-title">{room.name}</h5>
        <p className="text-muted mb-1">Size: {room.size}</p>
        <ul className="list-unstyled small">
          {room.facilities.map((f) => <li key={f}>✓ {f}</li>)}
        </ul>
        <p className="fw-bold text-primary">€{room.price} / night</p>
        <Link to="/booking" className="btn btn-brand w-100">Book Now</Link>
      </div>
    </div>
  );
}
