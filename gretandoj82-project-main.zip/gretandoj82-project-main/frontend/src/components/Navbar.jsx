import { Link, NavLink } from 'react-router-dom';

export default function Navbar() {
  const links = [
    ['/', 'Home'], ['/rooms', 'Rooms'], ['/facilities', 'Facilities'],
    ['/location', 'Location'], ['/reviews', 'Reviews'],
    ['/contact', 'Contact'], ['/booking', 'Book'], ['/admin', 'Admin'],
  ];
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
      <div className="container">
        <Link className="navbar-brand" to="/">ValëBlu</Link>
        <button className="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#nav">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="nav">
          <ul className="navbar-nav ms-auto">
            {links.map(([to, label]) => (
              <li className="nav-item" key={to}>
                <NavLink className="nav-link" to={to} end>{label}</NavLink>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </nav>
  );
}
