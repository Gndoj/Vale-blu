export default function Footer() {
  return (
    <footer className="text-center">
      <div className="container">
        <h5>ValëBlu, Ksamil</h5>
        <p className="mb-0">St. Butrinti, Ksamil, Albania</p>
        <small>© {new Date().getFullYear()} ValëBlu Hotel</small>
      </div>
    </footer>
  );
}
