import { useEffect, useState } from 'react';
import api from '../api';

export default function Admin() {
  const [bookings, setBookings] = useState([]);
  const load = () => api.get('/bookings').then(r => setBookings(r.data)).catch(() => {});
  useEffect(() => { load(); }, []);
  const remove = async (id) => { await api.delete(`/bookings/${id}`); load(); };
  return (
    <div className="container my-5">
      <h2 className="mb-4">Admin — Bookings</h2>
      <div className="table-responsive">
        <table className="table table-striped">
          <thead><tr><th>Customer</th><th>Room</th><th>Check-in</th><th>Check-out</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {bookings.map(b => (
              <tr key={b._id}>
                <td>{b.customerName}</td>
                <td>{b.roomId?.name || '—'}</td>
                <td>{new Date(b.checkIn).toLocaleDateString()}</td>
                <td>{new Date(b.checkOut).toLocaleDateString()}</td>
                <td><span className="badge bg-info">{b.status}</span></td>
                <td><button className="btn btn-sm btn-danger" onClick={() => remove(b._id)}>Delete</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
