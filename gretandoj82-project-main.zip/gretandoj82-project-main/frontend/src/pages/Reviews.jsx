import { useEffect, useState } from 'react';
import api from '../api';
import ReviewCard from '../components/ReviewCard.jsx';

export default function Reviews() {
  const [reviews, setReviews] = useState([]);
  useEffect(() => { api.get('/reviews').then(r => setReviews(r.data)).catch(() => {}); }, []);
  return (
    <div className="container my-5">
      <div className="text-center mb-4">
        <h2>Guest Reviews</h2>
        <h1 className="display-4 text-primary">9.7</h1>
        <p>Overall rating</p>
      </div>
      <div className="row g-4">
        {reviews.map(r => (<div className="col-md-4" key={r._id}><ReviewCard review={r} /></div>))}
      </div>
    </div>
  );
}
