import { useEffect, useState } from 'react';
import api from '../api';

export default function Booking() {
  const [rooms, setRooms] = useState([]);
  const [form, setForm] = useState({
    customerName: '', email: '', phone: '', roomId: '',
    checkIn: '', checkOut: '', guests: 1,
  });
  const [alert, setAlert] = useState(null);

  useEffect(() => { api.get('/rooms').then(r => setRooms(r.data)).catch(() => {}); }, []);

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    if (new Date(form.checkOut) <= new Date(form.checkIn)) {
      setAlert({ type: 'danger', text: 'Check-out must be after check-in.' });
      return;
    }
    try {
      await api.post('/bookings', form);
      setAlert({ type: 'success', text: 'Booking submitted!' });
      setForm({ customerName: '', email: '', phone: '', roomId: '', checkIn: '', checkOut: '', guests: 1 });
    } catch {
      setAlert({ type: 'danger', text: 'Booking failed.' });
    }
  };

  return (
    <div className="container my-5" style={{ maxWidth: 700 }}>
      <h2 className="mb-4">Book Your Stay</h2>
      {alert && <div className={`alert alert-${alert.type}`}>{alert.text}</div>}
      <form onSubmit={submit}>
        <input className="form-control mb-3" name="customerName" placeholder="Full name" value={form.customerName} onChange={change} required />
        <input className="form-control mb-3" type="email" name="email" placeholder="Email" value={form.email} onChange={change} required />
        <input className="form-control mb-3" name="phone" placeholder="Phone" value={form.phone} onChange={change} required />
        <select className="form-select mb-3" name="roomId" value={form.roomId} onChange={change} required>
          <option value="">Select a room</option>
          {rooms.map(r => <option key={r._id} value={r._id}>{r.name} — €{r.price}</option>)}
        </select>
        <div className="row">
          <div className="col"><label>Check-in</label><input className="form-control mb-3" type="date" name="checkIn" value={form.checkIn} onChange={change} required /></div>
          <div className="col"><label>Check-out</label><input className="form-control mb-3" type="date" name="checkOut" value={form.checkOut} onChange={change} required /></div>
        </div>
        <input className="form-control mb-3" type="number" min="1" name="guests" placeholder="Guests" value={form.guests} onChange={change} required />
        <button className="btn btn-brand w-100">Confirm Booking</button>
      </form>
    </div>
  );
}
