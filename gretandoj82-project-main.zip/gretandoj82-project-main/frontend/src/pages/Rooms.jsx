import { useEffect, useState } from 'react';
import api from '../api';
import RoomCard from '../components/RoomCard.jsx';

export default function Rooms() {
  const [rooms, setRooms] = useState([]);
  useEffect(() => { api.get('/rooms').then(r => setRooms(r.data)).catch(() => {}); }, []);
  return (
    <div className="container my-5">
      <h2 className="mb-4">Our Rooms</h2>
      <div className="row g-4">
        {rooms.map(r => (<div className="col-md-4" key={r._id}><RoomCard room={r} /></div>))}
      </div>
    </div>
  );
}
