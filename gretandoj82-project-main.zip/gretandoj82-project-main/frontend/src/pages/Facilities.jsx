const items = [
  { icon: 'bi-tree', name: 'Garden' },
  { icon: 'bi-sun', name: 'Terrace' },
  { icon: 'bi-fire', name: 'BBQ Area' },
  { icon: 'bi-p-square', name: 'Free Private Parking' },
  { icon: 'bi-wifi', name: 'Free WiFi' },
  { icon: 'bi-snow', name: 'Air Conditioning' },
];

export default function Facilities() {
  return (
    <div className="container my-5">
      <h2 className="mb-4 text-center">Facilities</h2>
      <div className="row g-4">
        {items.map(it => (
          <div className="col-md-4" key={it.name}>
            <div className="card text-center p-4 h-100">
              <i className={`bi ${it.icon} facility-icon mb-2`}></i>
              <h5>{it.name}</h5>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
