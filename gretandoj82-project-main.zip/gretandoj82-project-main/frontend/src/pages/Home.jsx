import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import api from '../api';
import RoomCard from '../components/RoomCard.jsx';

export default function Home() {
  const [rooms, setRooms] = useState([]);
  useEffect(() => { api.get('/rooms').then(r => setRooms(r.data.slice(0, 3))).catch(() => {}); }, []);
  return (
    <>
      <section className="hero">
        <h1>ValëBlu, Ksamil</h1>
        <p className="lead">A modern beach hotel on the Albanian Riviera</p>
        <Link to="/booking" className="btn btn-brand btn-lg mt-3">Book Now</Link>
      </section>
      <section className="container my-5">
        <h2 className="text-center mb-4">Featured Rooms</h2>
        <div className="row g-4">
          {rooms.map(r => (
            <div className="col-md-4" key={r._id}><RoomCard room={r} /></div>
          ))}
        </div>
      </section>
    </>
  );
}
