export default function Location() {
  return (
    <div className="container my-5">
      <h2 className="mb-3">Location</h2>
      <p><strong>Address:</strong> St. Butrinti, Ksamil, Albania</p>
      <div className="ratio ratio-16x9 mb-4">
        <iframe
          title="map"
          src="https://www.google.com/maps?q=Ksamil,Albania&output=embed"
          allowFullScreen
        ></iframe>
      </div>
      <h5>Nearby beach</h5>
      <p>The hotel is just a short walk from the famous Ksamil beaches with crystal-clear turquoise water.</p>
    </div>
  );
}
