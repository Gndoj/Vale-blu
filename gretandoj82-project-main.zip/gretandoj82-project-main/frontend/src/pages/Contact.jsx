import { useState } from 'react';
import api from '../api';

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [alert, setAlert] = useState(null);
  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });
  const submit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/contact', form);
      setAlert({ type: 'success', text: 'Message sent!' });
      setForm({ name: '', email: '', message: '' });
    } catch {
      setAlert({ type: 'danger', text: 'Could not send message.' });
    }
  };
  return (
    <div className="container my-5" style={{ maxWidth: 600 }}>
      <h2 className="mb-4">Contact Us</h2>
      {alert && <div className={`alert alert-${alert.type}`}>{alert.text}</div>}
      <form onSubmit={submit}>
        <input className="form-control mb-3" name="name" placeholder="Name" value={form.name} onChange={change} required />
        <input className="form-control mb-3" type="email" name="email" placeholder="Email" value={form.email} onChange={change} required />
        <textarea className="form-control mb-3" name="message" rows="4" placeholder="Message" value={form.message} onChange={change} required />
        <button className="btn btn-brand">Send</button>
      </form>
    </div>
  );
}
