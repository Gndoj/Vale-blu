// Run with: node seed.js
const dotenv = require('dotenv');
const connectDB = require('./config/db');
const Room = require('./models/Room');
const Review = require('./models/Review');

dotenv.config();

const rooms = [
  {
    name: 'Deluxe Sea View',
    size: '35m²',
    facilities: ['Family Room', 'Private Kitchen', 'TV', 'WiFi', 'Air Conditioning'],
    price: 120,
    image: 'https://images.unsplash.com/photo-1501117716987-c8e1ecb2106?auto=format&fit=crop&w=900',
  },
  {
    name: 'Family Suite',
    size: '35m²',
    facilities: ['Family Room', 'Private Kitchen', 'TV', 'WiFi', 'Air Conditioning'],
    price: 150,
    image: 'https://images.unsplash.com/photo-1551776235-dde6d4829808?auto=format&fit=crop&w=900',
  },
  {
    name: 'Garden Apartment',
    size: '35m²',
    facilities: ['Family Room', 'Private Kitchen', 'TV', 'WiFi', 'Air Conditioning'],
    price: 110,
    image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=900',
  },
];

const reviews = [
  { userName: 'Anna', rating: 5, comment: 'Beautiful beach, amazing staff!' },
  { userName: 'Marko', rating: 5, comment: 'Spotless rooms and great location.' },
  { userName: 'Elira', rating: 4, comment: 'Lovely terrace and BBQ area.' },
];

(async () => {
  await connectDB();
  await Room.deleteMany();
  await Review.deleteMany();
  await Room.insertMany(rooms);
  await Review.insertMany(reviews);
  console.log('Seed complete');
  process.exit();
})();
