const Contact = require('../models/Contact');

exports.createContact = async (req, res) => {
  try {
    const message = await Contact.create(req.body);
    res.status(201).json({ message: 'Message received', data: message });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};
